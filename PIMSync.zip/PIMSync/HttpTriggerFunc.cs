using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Azure.Identity;
using GroupSyncApp.Services;
using Microsoft.Graph;

namespace GroupSyncApp.Functions
{
    public static class SyncFunction
    {
        [FunctionName("SyncFunction")]
        public static async Task Run(
            [TimerTrigger("0,30 * * * * *")] TimerInfo myTimer,
            ILogger log)
        {
            log.LogInformation($"SyncFunction Timer triggered at: {DateTime.UtcNow}");

            var tenantId = Environment.GetEnvironmentVariable("TENANT_ID");
            var clientId = Environment.GetEnvironmentVariable("CLIENT_ID");
            var clientSecret = Environment.GetEnvironmentVariable("CLIENT_SECRET");
            var teamsWebhookUrl = Environment.GetEnvironmentVariable("TEAMS_WEBHOOK_URL");
            string groupPairsJsonPath = "groupPairs.json";

            if (string.IsNullOrEmpty(tenantId) || string.IsNullOrEmpty(clientId) ||
                string.IsNullOrEmpty(clientSecret) || string.IsNullOrEmpty(teamsWebhookUrl))
            {
                log.LogError("Environment variables not set.");
                return;
            }

            var groupPairs = ConfigLoader.LoadGroupPairs(groupPairsJsonPath, log);
            if (groupPairs == null || groupPairs.Count == 0)
            {
                log.LogError("No group pairs found in the JSON file.");
                return;
            }

            var clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);
            var graphClient = new GraphServiceClient(clientSecretCredential);

            foreach (var groupPair in groupPairs)
            {
                if (string.IsNullOrEmpty(groupPair.SourceGroupId) || string.IsNullOrEmpty(groupPair.TargetGroupId))
                {
                    log.LogWarning("Group pair contains null or empty SourceGroupId/TargetGroupId, skipping...");
                    continue;
                }

                log.LogInformation($"Processing Group Pair: Source: {groupPair.SourceGroupId}, Target: {groupPair.TargetGroupId}");

                await GroupSync.SyncGroupMembersAsync(
                    graphClient,
                    teamsWebhookUrl,
                    groupPair,
                    clientSecretCredential,
                    tenantId,
                    log
                );

                log.LogInformation($"Finished processing Group Pair: {groupPair.SourceGroupId}");
            }

            log.LogInformation($"Function completed at {DateTime.UtcNow}");
        }
    }
}
