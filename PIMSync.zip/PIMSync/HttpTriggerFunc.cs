using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using GroupSyncApp.Models;
using GroupSyncApp.Services;
using Microsoft.Graph;
using System.Collections.Generic;

namespace GroupSyncApp.Functions
{
    public static class SyncFunction
    {
        [FunctionName("SyncFunction")]
        public static async Task Run(
            [TimerTrigger("0,30 * * * * *")] TimerInfo myTimer,
            ILogger log)
        {
            log.LogInformation($"SyncFunction Timer triggered at: {DateTime.UtcNow}");

            var tenantId = Environment.GetEnvironmentVariable("TENANT_ID");
            var clientId = Environment.GetEnvironmentVariable("CLIENT_ID");
            var clientSecret = Environment.GetEnvironmentVariable("CLIENT_SECRET");
            var teamsWebhookUrl = Environment.GetEnvironmentVariable("TEAMS_WEBHOOK_URL");
            string groupPairsJsonPath = "groupPairs.json";

            var sb = new StringBuilder();
            sb.AppendLine($"Function started at {DateTime.UtcNow}");

            if (string.IsNullOrEmpty(tenantId) || string.IsNullOrEmpty(clientId) ||
                string.IsNullOrEmpty(clientSecret) || string.IsNullOrEmpty(teamsWebhookUrl))
            {
                log.LogError("Environment variables not set.");
                sb.AppendLine("Error: Environment variables not set.");
                await SaveLogsToBlobAsync(sb, log);
                return;
            }

            var groupPairs = ConfigLoader.LoadGroupPairs(groupPairsJsonPath, log);
            if (groupPairs == null || groupPairs.Count == 0)
            {
                log.LogError("No group pairs found in the JSON file.");
                sb.AppendLine("No group pairs found in the JSON file.");
                await SaveLogsToBlobAsync(sb, log);
                return;
            }

            var clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);
            var graphClient = new GraphServiceClient(clientSecretCredential);

            foreach (var groupPair in groupPairs)
            {
                if (string.IsNullOrEmpty(groupPair.SourceGroupId) || string.IsNullOrEmpty(groupPair.TargetGroupId))
                {
                    log.LogWarning("Group pair contains null or empty SourceGroupId/TargetGroupId, skipping...");
                    sb.AppendLine("Group pair contains null or empty SourceGroupId/TargetGroupId, skipping...");
                    continue;
                }

                log.LogInformation($"Processing Group Pair: Source: {groupPair.SourceGroupId}, Target: {groupPair.TargetGroupId}");
                sb.AppendLine($"Processing Group Pair: Source: {groupPair.SourceGroupId}, Target: {groupPair.TargetGroupId}");

                await GroupSync.SyncGroupMembersAsync(
                    graphClient,
                    teamsWebhookUrl,
                    groupPair,
                    clientSecretCredential,
                    tenantId,
                    log
                );

                sb.AppendLine($"Finished processing Group Pair: {groupPair.SourceGroupId}");
            }

            sb.AppendLine($"Function completed at {DateTime.UtcNow}");
            await SaveLogsToBlobAsync(sb, log);
        }

        private static async Task SaveLogsToBlobAsync(StringBuilder sb, ILogger log)
        {
            try
            {
                string connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                if (string.IsNullOrEmpty(connectionString))
                {
                    log.LogError("AzureWebJobsStorage is not set. Cannot save logs to blob.");
                    return;
                }

                var containerName = "operationlogs";
                var blobServiceClient = new BlobServiceClient(connectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient(containerName);
                await containerClient.CreateIfNotExistsAsync(PublicAccessType.None);

                var now = DateTime.UtcNow;
                string blobName = $"{now:yyyy/MM/dd}/logs.txt";
                var blobClient = containerClient.GetBlobClient(blobName);

                string existingContent = "";
                if (await blobClient.ExistsAsync())
                {
                    var downloadInfo = await blobClient.DownloadContentAsync();
                    existingContent = downloadInfo.Value.Content.ToString();
                }

                var finalContent = existingContent + sb.ToString();

                using var stream = new MemoryStream(Encoding.UTF8.GetBytes(finalContent));
                await blobClient.UploadAsync(stream, overwrite: true);

                log.LogInformation("Logs have been successfully saved to blob storage.");
            }
            catch (Exception ex)
            {
                log.LogError($"Failed to save logs to blob storage: {ex.Message}");
            }
        }
    }
}
