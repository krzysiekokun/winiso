using Newtonsoft.Json;
using GroupSyncApp.Models;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using Microsoft.Extensions.Logging;

namespace GroupSyncApp.Services
{
    public static class TeamsNotifier
    {
        public static async Task SendTeamsNotificationsAsync(
            string teamsWebhookUrl, 
            List<UserInfo> addedUsers, 
            List<UserInfo> skippedUsers, 
            List<UserInfo> removedUsers,
            ILogger log)
        {
            if (addedUsers.Any())
            {
                await SendMessageToTeamsAsync(teamsWebhookUrl, "Users Added to Target Group", addedUsers, log);
            }
            if (skippedUsers.Any())
            {
                await SendMessageToTeamsAsync(teamsWebhookUrl, "Users Skipped Due to MFA Issues", skippedUsers, log);
            }
            if (removedUsers.Any())
            {
                await SendMessageToTeamsAsync(teamsWebhookUrl, "Users Removed from Target Group", removedUsers, log);
            }
        }

        private static async Task SendMessageToTeamsAsync(
            string teamsWebhookUrl, 
            string title, 
            List<UserInfo> users,
            ILogger log)
        {
            var messageSections = new List<object>();

            foreach (var user in users)
            {
                var facts = new List<object>
                {
                    new { name = "MFA Status", value = user.MfaStatus },
                    new { name = "MFA Methods", value = user.MfaMethods }
                };

                if (!string.IsNullOrEmpty(user.Reason))
                {
                    facts.Insert(0, new { name = "Reason", value = user.Reason });
                }

                var section = new
                {
                    activityTitle = $"**{user.DisplayName}** ({user.UserPrincipalName})",
                    facts = facts,
                    markdown = true
                };
                messageSections.Add(section);
            }

            var messagePayload = new
            {
                @type = "MessageCard",
                @context = "http://schema.org/extensions",
                summary = title,
                themeColor = "EA4300",
                title = title,
                sections = messageSections
            };

            var jsonPayload = JsonConvert.SerializeObject(messagePayload);

            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.PostAsync(
                    teamsWebhookUrl, 
                    new StringContent(jsonPayload, Encoding.UTF8, "application/json")
                );

                if (!response.IsSuccessStatusCode)
                {
                    log.LogError($"Failed to send notification to Teams: {response.StatusCode} - {response.ReasonPhrase}");
                }
                else
                {
                    log.LogInformation("Teams notification sent successfully.");
                }
            }
        }
    }
}
