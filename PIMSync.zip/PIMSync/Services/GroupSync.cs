using Azure.Identity;
using Microsoft.Graph;
using Newtonsoft.Json;
using GroupSyncApp.Models;
using GroupSyncApp.Services;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Logging;

namespace GroupSyncApp.Services
{
    public static class GroupSync
    {
        public static async Task SyncGroupMembersAsync(
            GraphServiceClient graphClient,
            string teamsWebhookUrl,
            GroupPair groupPair,
            ClientSecretCredential credential,
            string tenantId,
            ILogger log)
        {
            var sourceMembers = await GraphHelper.GetGroupMembersAsync(graphClient, groupPair.SourceGroupId!);
            var targetMembers = await GraphHelper.GetGroupMembersAsync(graphClient, groupPair.TargetGroupId!);

            var sourceMemberIds = new HashSet<string>(sourceMembers.Select(u => u.Id!));
            var targetMemberIds = new HashSet<string>(targetMembers.Select(u => u.Id!));

            var addedUsers = new List<UserInfo>();
            var removedUsers = new List<UserInfo>();
            var skippedUsers = new List<UserInfo>();

            var addTasks = new List<Task>();
            var removeTasks = new List<Task>();

            foreach (var user in sourceMembers)
            {
                var (hasMfa, mfaMethods, requireReRegister) = await GraphHelper.GetMfaStatusAsync(credential, tenantId, user.Id!);

                if (hasMfa && !requireReRegister)
                {
                    if (!targetMemberIds.Contains(user.Id!))
                    {
                        addedUsers.Add(new UserInfo(user, "Configured", string.Join(", ", mfaMethods)));
                        addTasks.Add(RetryWithBackoff(async () =>
                        {
                            await graphClient.Groups[groupPair.TargetGroupId!].Members.Ref.PostAsync(
                                new Microsoft.Graph.Models.ReferenceCreate
                                {
                                    OdataId = $"https://graph.microsoft.com/v1.0/directoryObjects/{user.Id}"
                                }
                            );
                            log.LogInformation($"Added member {user.DisplayName} ({user.UserPrincipalName}) to the target group.");
                        }, log));
                    }
                }
                else
                {
                    var reason = !hasMfa ? "No MFA configured" : "Requires MFA re-registration";
                    skippedUsers.Add(new UserInfo(user, hasMfa ? "Requires Re-register" : "Not Configured", string.Join(", ", mfaMethods), reason));
                    log.LogInformation($"Skipped user {user.DisplayName} ({user.UserPrincipalName}) due to MFA issues.");
                }
            }

            foreach (var user in targetMembers)
            {
                if (!sourceMemberIds.Contains(user.Id!))
                {
                    removedUsers.Add(new UserInfo(user, "N/A", "N/A", "Not in source group"));
                    removeTasks.Add(RetryWithBackoff(async () =>
                    {
                        await graphClient.Groups[groupPair.TargetGroupId!].Members[user.Id!].Ref.DeleteAsync();
                        log.LogInformation($"Removed member {user.DisplayName} ({user.UserPrincipalName}) from the target group (Not in source group).");
                    }, log));
                }
                else
                {
                    var (hasMfa, mfaMethods, requireReRegister) = await GraphHelper.GetMfaStatusAsync(credential, tenantId, user.Id!);
                    if (!hasMfa || requireReRegister)
                    {
                        removedUsers.Add(new UserInfo(user, hasMfa ? "Requires Re-register" : "Not Configured", string.Join(", ", mfaMethods), "MFA not configured or requires re-registration"));
                        removeTasks.Add(RetryWithBackoff(async () =>
                        {
                            await graphClient.Groups[groupPair.TargetGroupId!].Members[user.Id!].Ref.DeleteAsync();
                            log.LogInformation($"Removed member {user.DisplayName} ({user.UserPrincipalName}) from the target group (MFA issues).");
                        }, log));
                    }
                }
            }

            if (addTasks.Count > 0)
            {
                await Task.WhenAll(addTasks);
            }

            if (removeTasks.Count > 0)
            {
                await Task.WhenAll(removeTasks);
            }

            await TeamsNotifier.SendTeamsNotificationsAsync(teamsWebhookUrl, addedUsers, skippedUsers, removedUsers, log);
        }

        private static async Task RetryWithBackoff(Func<Task> operation, ILogger log, int maxRetries = 3)
        {
            int delay = 1000;
            for (int i = 0; i < maxRetries; i++)
            {
                try
                {
                    await operation();
                    return; 
                }
                catch (Exception ex)
                {
                    log.LogWarning($"Operation failed (attempt {i + 1}/{maxRetries}): {ex.Message}");
                    if (i == maxRetries - 1)
                    {
                        throw;
                    }
                    await Task.Delay(delay);
                    delay *= 2;
                }
            }
        }
    }
}
