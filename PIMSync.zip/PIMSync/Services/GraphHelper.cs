using Azure.Identity;
using Microsoft.Graph;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using System;
using System.IO;
using System.Linq;




namespace GroupSyncApp.Services
{
    public static class GraphHelper
    {
        public static async Task<List<Microsoft.Graph.Models.User>> GetGroupMembersAsync(GraphServiceClient graphClient, string groupId)
        {
            var members = new List<Microsoft.Graph.Models.User>();
            var result = await graphClient.Groups[groupId].Members.GetAsync((requestConfiguration) =>
            {
                requestConfiguration.QueryParameters.Select = new[] { "id", "displayName", "userPrincipalName" };
            });

            while (result?.Value != null)
            {
                members.AddRange(result.Value.OfType<Microsoft.Graph.Models.User>());
                if (result.OdataNextLink != null)
                {
                    result = await graphClient.Groups[groupId].Members.GetAsync((config) =>
                    {
                        config.Headers.Add("ConsistencyLevel", "eventual");
                    });
                }
                else
                {
                    break;
                }
            }

            return members;
        }

        public static async Task<(bool HasMfa, List<string> MfaMethods, bool RequireReRegister)> GetMfaStatusAsync(ClientSecretCredential credential, string tenantId, string userId)
        {
            var scopes = new[] { "https://graph.microsoft.com/.default" };
            var token = await credential.GetTokenAsync(new Azure.Core.TokenRequestContext(scopes));

            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token.Token);

                var betaEndpoint = $"https://graph.microsoft.com/beta/users/{userId}/authentication/methods";
                var response = await httpClient.GetAsync(betaEndpoint);
                var content = await response.Content.ReadAsStringAsync();
                dynamic? methodsData = JsonConvert.DeserializeObject(content);

                List<string> mfaMethodTypes = new List<string>
                {
                    "microsoftAuthenticatorAuthenticationMethod",
                    "phoneAuthenticationMethod",
                    "softwareOathAuthenticationMethod",
                    "fido2AuthenticationMethod",
                    "windowsHelloForBusinessAuthenticationMethod",
                    "temporaryAccessPassAuthenticationMethod"
                };

                var userMfaMethods = new List<string>();
                if (methodsData?.value != null)
                {
                    foreach (var method in methodsData.value)
                    {
                        string methodType = method["@odata.type"];
                        methodType = methodType.Replace("#microsoft.graph.", "");
                        if (mfaMethodTypes.Contains(methodType))
                        {
                            userMfaMethods.Add(methodType);
                        }
                    }
                }
                bool hasMfa = userMfaMethods.Count > 0;

                var reauthEndpoint = $"https://graph.microsoft.com/beta/users/{userId}?$select=strongAuthenticationRequirements";
                var reauthResponse = await httpClient.GetAsync(reauthEndpoint);
                var reauthContent = await reauthResponse.Content.ReadAsStringAsync();
                dynamic? reauthData = JsonConvert.DeserializeObject(reauthContent);

                bool requireReRegister = false;
                if (reauthData?.strongAuthenticationRequirements != null)
                {
                    foreach (var req in reauthData.strongAuthenticationRequirements)
                    {
                        string state = req.state;
                        if (state == "requireReauthentication")
                        {
                            requireReRegister = true;
                            break;
                        }
                    }
                }

                return (hasMfa, userMfaMethods, requireReRegister);
            }
        }
    }
}
