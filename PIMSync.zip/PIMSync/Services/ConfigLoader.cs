using Newtonsoft.Json;
using GroupSyncApp.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Linq;
using Microsoft.Extensions.Logging;

namespace GroupSyncApp.Services
{
    public static class ConfigLoader
    {
        public static List<GroupPair>? LoadGroupPairs(string filePath, ILogger log)
        {
            if (!File.Exists(filePath))
            {
                log.LogError($"Group pairs JSON file not found: {filePath}");
                return null;
            }

            return JsonConvert.DeserializeObject<List<GroupPair>>(File.ReadAllText(filePath));
        }
    }
}
