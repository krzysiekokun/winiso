namespace GroupSyncApp.Models
{
    public class GroupPair
    {
        public string? SourceGroupId { get; set; }
        public string? TargetGroupId { get; set; }
    }

    public class UserInfo
    {
        public string? DisplayName { get; set; }
        public string? UserPrincipalName { get; set; }
        public string MfaStatus { get; set; }
        public string MfaMethods { get; set; }
        public string Reason { get; set; }

        public UserInfo(Microsoft.Graph.Models.User user, string mfaStatus = "N/A", string mfaMethods = "N/A", string reason = "")
        {
            DisplayName = user.DisplayName;
            UserPrincipalName = user.UserPrincipalName;
            MfaStatus = mfaStatus;
            MfaMethods = mfaMethods;
            Reason = reason;
        }
    }
}